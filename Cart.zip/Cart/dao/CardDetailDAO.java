package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.CardDetail;

public interface CardDetailDAO {

	void saveOrUpdate(CardDetail cardDetail);
	
}
