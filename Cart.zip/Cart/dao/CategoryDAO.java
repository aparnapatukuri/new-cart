package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;

public interface CategoryDAO {

	void saveOrUpdate(Category category);
	
	void delete(String id);
	
	Category get(String id);
	
	public List<Category> listCategory();
	
	List<Product> selectedCategoryProductList(String id);
	
	List<Product> selectAllCategoryProducts(String categoryId);
	
	int getProductCountByCategory(String id);	
}
