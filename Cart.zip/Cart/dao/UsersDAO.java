package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.Users;

public interface UsersDAO {

	void saveOrUpdate(Users users);
	
	void delete(String customerId);
}
